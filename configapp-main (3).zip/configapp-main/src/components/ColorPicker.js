import React, { useState ,useEffect } from "react";
import { RgbaColorPicker } from "react-colorful";

export default function App({name , elevatorCart , setelevatorCart}) {
  const [color, setColor] = useState({ r: 200, g: 150, b: 35, a: 0.5 });


useEffect(() => {
  let cartCreator
let checkIfFound 
let newcart
if (elevatorCart?.length > 1){
   checkIfFound = elevatorCart.find(eachobj => Object.keys(eachobj).join() === {name} )
    }
if(checkIfFound){
 newcart = [...elevatorCart].filter((each) => {
    return Object.keys(each).join() !== {name}
  })
let propertyNames = Object.keys(color);
let propertyValues = Object.values(color);
let NewColor = propertyNames.map((eachkey,i) =>{
 return `${eachkey}:${propertyValues[i]}`

})

  cartCreator = {...newcart ,[name]:NewColor.join()} 
    setelevatorCart([cartCreator])
}
    else{
  let propertyNames = Object.keys(color);
let propertyValues = Object.values(color);
let NewColor = propertyNames.map((eachkey,i) =>{
 return `${eachkey}:${propertyValues[i]}`

})

    cartCreator = {...elevatorCart ,[name]:NewColor.join() }
    setelevatorCart(cartCreator)

    }


}, [color])









  return (
    <div className="color-picker" style={{padding:'20px', margin:'5px'}}>
        <p>{name}</p>
      <RgbaColorPicker color={color} onChange={setColor} />

      <div className="value" style={{padding:'10px'}}>{JSON.stringify(color)}</div>

      
    </div>
  );
}
