import * as React  from 'react';
import  {useEffect} from 'react'
import Table from '@mui/joy/Table';
import { CSVLink } from "react-csv";
import Paper from "@material-ui/core/Paper";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import {SiMicrosoftexcel} from "react-icons/si"
import {AiFillCloseCircle} from "react-icons/ai"



const SimpleTable= ({cart,setcart}) => {
    
    

    


   const handlecancel =  ((item) => {

   let updatedcart = cart.filter(cartitem => {
  return cartitem !== item
   })

 setcart(updatedcart)
localStorage.setItem('cart' , JSON.stringify(updatedcart))



   })











let headers = [
    
  { label: "type", key: "type" },
  { label: "Motor", key: "motor" },
  { label: "Height", key: "height" },
  { label: "Width", key: "width" },
  { label: "Speed", key: "speed" },
  { label: "Power", key: "power" },
 
];
let headerelev = [
  { label: 'Name', key: 'name' },
  { label: 'Cabin Type', key: 'Cabin Type' },
  { label: 'Horizontal Distance (In ft)', key: 'Horizontal Distance (In ft)' },
  { label: 'Vertical Distance (In ft)', key: 'Vertical Distance (In ft)' },
  { label: 'Number of Stops', key: 'Number of Stops' },
  { label: 'Cabin Style', key: 'Cabin Style' },
  { label: 'Cabin floor Color', key: 'Cabin floor Color' },
  { label: 'Door Color', key: 'Door Color' },
  { label: 'Door Styles', key: 'Door Styles' },
];



    let escalator = cart.filter(item => {
    
    return item.type 

    })

    let elevator = cart.filter(item => {
    
    return item.name

    })
    
  return (
      <div className='cart'>
     
<Paper  style={{width: "100%",
    marginTop: '20px' , marginBottom:'60px' , 
    overflowX: "auto",color:'black'}}>
      <Table style={{minWidth: "700px" ,color:'black' }}>
    <caption  style={{color:'black' , backgroundColor:"yellow"}}>Product Cart (Escalator)</caption>
        <TableHead>
          <TableRow style={{backgroundColor:"#ddd"}}>
            <TableCell>Remove</TableCell>
            <TableCell>Type</TableCell>
            <TableCell >Motor</TableCell>
            <TableCell >Height</TableCell>
            <TableCell >Width</TableCell>
            <TableCell >Speed</TableCell>
            <TableCell >Power</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {
                escalator.map((item , i) => (
              <TableRow style={{backgroundColor:"#ddd"}} key={i}>
                
                <TableCell onClick={() => handlecancel(item)} className='removefrom' >{<AiFillCloseCircle color='black' size={20}/>}</TableCell>
                <TableCell component="th" scope="row">
                  {item.type}
                </TableCell>
                <TableCell >{item.motor}</TableCell>
                <TableCell >{item.height}</TableCell>
                <TableCell >{item.width}</TableCell>
                <TableCell >{item.speed}</TableCell>
                <TableCell >{item.power}</TableCell>
                
              </TableRow>
            )) }
        </TableBody>
      </Table>
    </Paper>
    {escalator.length >= 1 && 
 <CSVLink data={escalator}   headers={headers} className='excel' >
  <SiMicrosoftexcel size={20}/> Export Excel sheet
</CSVLink>}
<Paper  style={{width: "100%",
    marginTop: '20px' , marginBottom:'60px' , 
    overflowX: "auto",color:'black'}}>
      <Table style={{minWidth: "700px" ,color:'black' }}>
    <caption  style={{color:'black' , backgroundColor:"yellow"}}>Product Cart (Elevator)</caption>
        <TableHead>
          <TableRow style={{backgroundColor:"#ddd"}}>
            
            <TableCell >Remove</TableCell>
            <TableCell >Name</TableCell>
            <TableCell >Cabin Type</TableCell>
            <TableCell >Horizontal Distance (ft)</TableCell>
            <TableCell >Vertical Distance (In ft)</TableCell>
            <TableCell >Number of Stops</TableCell>
            <TableCell >Cabin Style</TableCell>
            <TableCell >Cabin floor Color</TableCell>
            <TableCell >Door Color</TableCell>
            <TableCell >Door Styles</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {
                elevator.map((item , i) => (
              <TableRow style={{backgroundColor:"#ddd"}} key={i}>
                <TableCell onClick={() => handlecancel(item)} className='removefrom' >{<AiFillCloseCircle size={20} color="black"/>}</TableCell>
                <TableCell component="th" scope="row">
                  {item.name}
                </TableCell>
                <TableCell >{item['Cabin Type']}</TableCell>
                <TableCell >{item['Horizontal Distance (In ft)']}</TableCell>
                <TableCell >{item['Vertical Distance (In ft)']}</TableCell>
                <TableCell >{item['Number of Stops']}</TableCell>
                <TableCell >{item['Cabin Style']}</TableCell>
                <TableCell >{item['Cabin floor Color'] ? item['Cabin floor Color'] : 'Default:white' }</TableCell>
                <TableCell >{item['Door Color'] ? item['Door Color'] : 'Default:white'}</TableCell>
                <TableCell >{item['Door Styles']}</TableCell>
                
                
              </TableRow>
            )) }
        </TableBody>
      </Table>
    </Paper>

{elevator.length >= 1 &&    
      <CSVLink data={elevator}   headers={headerelev} className='excel' >
 <SiMicrosoftexcel size={20}/> Export Excel sheet
</CSVLink>
}

    </div>
  );
  }




export default SimpleTable;


